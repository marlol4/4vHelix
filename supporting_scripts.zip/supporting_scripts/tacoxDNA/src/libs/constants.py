mass_in_lammps = 3.1575
inertia_in_lammps = 0.435179
number_oxdna_to_lammps = {0 : 0, 1 : 2, 2 : 1, 3 : 3}
